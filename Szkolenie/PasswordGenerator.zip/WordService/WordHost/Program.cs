﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WordService;

namespace WordHost
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(WordServiceManager));
            Console.WriteLine("Uruchamiam serwis");
            host.Opened += host_Opened;
            host.Faulted += host_Faulted;
            host.Open();
            Console.WriteLine("Wciśnij Enter aby zakończyć");
            Console.ReadLine();
            host.Close();

        }

        static void host_Faulted(object sender, EventArgs e)
        {
            Console.WriteLine("Serwis nie jest uruchomiony; wystąpił błąd");
        }

        static void host_Opened(object sender, EventArgs e)
        {
            Console.WriteLine("Serwis uruchomiony");
        }
    }
}
