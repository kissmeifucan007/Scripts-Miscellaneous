﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    public class SimpleWordList : Component, IWordList
    {
        protected List<string> wordList = new List<string>();
        public virtual List<string> WordList { get; set; } 
        protected string description;
        public string Description { get { return description; } set { description = value; } }

      // List<string> IWordList.WordList { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
      //  string IWordList.Description { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }


        public string GetRandomWord()
        {
            Random rnd = new Random();
            return WordList[rnd.Next(0, wordList.Capacity)];
        }

        public string GetRandomWord(int n)
        {
            string result = "";
            for (int i = 0; i < n; i++)
            {
                result += GetRandomWord();
            }
            return result;
        }

        public SimpleWordList() {
        }

        public SimpleWordList(string description)
            :this()
        {
            this.description = description;
        }

        public SimpleWordList(List<string> wordList, string description)
            :this(description)
         {
            this.wordList = wordList;
        }

    }
}
