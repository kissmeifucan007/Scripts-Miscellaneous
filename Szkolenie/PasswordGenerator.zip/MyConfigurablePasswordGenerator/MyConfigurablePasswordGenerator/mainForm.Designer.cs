﻿namespace MyConfigurablePasswordGenerator
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadDictionaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateButton = new System.Windows.Forms.Button();
            this.noOfPasswordsLabel = new System.Windows.Forms.Label();
            this.noOfPasswordsTextField = new System.Windows.Forms.TextBox();
            this.lengThextBox = new System.Windows.Forms.TextBox();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.generatedPasswordsTextBox = new System.Windows.Forms.TextBox();
            this.GeneratedPasswordsLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.loadedDictionaryPathTextBox = new System.Windows.Forms.TextBox();
            this.allowedCharactersCheckedListBox = new System.Windows.Forms.CheckedListBox();
            this.CharSetListBox = new System.Windows.Forms.ListBox();
            this.openDictionaryFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.basicEnglishCharacterSet1 = new MyConfigurablePasswordGenerator.BasicEnglishCharacterSet();
            this.polishCharacterSet1 = new MyConfigurablePasswordGenerator.PolishCharacterSet();
            this.fileWordList1 = new MyConfigurablePasswordGenerator.FileWordList();
            this.wordListFromService1 = new MyConfigurablePasswordGenerator.WordListFromService();
            this.mainMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(771, 24);
            this.mainMenuStrip.TabIndex = 0;
            this.mainMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadDictionaryToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadDictionaryToolStripMenuItem
            // 
            this.loadDictionaryToolStripMenuItem.Name = "loadDictionaryToolStripMenuItem";
            this.loadDictionaryToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.loadDictionaryToolStripMenuItem.Text = "Load dictionary";
            this.loadDictionaryToolStripMenuItem.Click += new System.EventHandler(this.loadDictionaryToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.closeToolStripMenuItem.Text = "Save default settings";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // generateButton
            // 
            this.generateButton.Location = new System.Drawing.Point(12, 27);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(269, 23);
            this.generateButton.TabIndex = 1;
            this.generateButton.Text = "Generate";
            this.generateButton.UseVisualStyleBackColor = true;
            // 
            // noOfPasswordsLabel
            // 
            this.noOfPasswordsLabel.AutoSize = true;
            this.noOfPasswordsLabel.Location = new System.Drawing.Point(287, 84);
            this.noOfPasswordsLabel.Name = "noOfPasswordsLabel";
            this.noOfPasswordsLabel.Size = new System.Drawing.Size(169, 13);
            this.noOfPasswordsLabel.TabIndex = 2;
            this.noOfPasswordsLabel.Text = "Number of passwords to generate:";
            // 
            // noOfPasswordsTextField
            // 
            this.noOfPasswordsTextField.Location = new System.Drawing.Point(462, 81);
            this.noOfPasswordsTextField.Name = "noOfPasswordsTextField";
            this.noOfPasswordsTextField.Size = new System.Drawing.Size(39, 20);
            this.noOfPasswordsTextField.TabIndex = 3;
            this.noOfPasswordsTextField.Text = "1";
            // 
            // lengThextBox
            // 
            this.lengThextBox.Location = new System.Drawing.Point(462, 107);
            this.lengThextBox.Name = "lengThextBox";
            this.lengThextBox.Size = new System.Drawing.Size(39, 20);
            this.lengThextBox.TabIndex = 5;
            this.lengThextBox.Text = "8";
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(368, 110);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(88, 13);
            this.lengthLabel.TabIndex = 4;
            this.lengthLabel.Text = "Password length:";
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(519, 32);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(201, 13);
            this.descriptionLabel.TabIndex = 7;
            this.descriptionLabel.Text = "Password generating method description:";
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Location = new System.Drawing.Point(522, 55);
            this.descriptionTextBox.Multiline = true;
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(198, 178);
            this.descriptionTextBox.TabIndex = 8;
            // 
            // generatedPasswordsTextBox
            // 
            this.generatedPasswordsTextBox.Location = new System.Drawing.Point(12, 84);
            this.generatedPasswordsTextBox.Multiline = true;
            this.generatedPasswordsTextBox.Name = "generatedPasswordsTextBox";
            this.generatedPasswordsTextBox.Size = new System.Drawing.Size(269, 149);
            this.generatedPasswordsTextBox.TabIndex = 9;
            // 
            // GeneratedPasswordsLabel
            // 
            this.GeneratedPasswordsLabel.AutoSize = true;
            this.GeneratedPasswordsLabel.Location = new System.Drawing.Point(12, 62);
            this.GeneratedPasswordsLabel.Name = "GeneratedPasswordsLabel";
            this.GeneratedPasswordsLabel.Size = new System.Drawing.Size(113, 13);
            this.GeneratedPasswordsLabel.TabIndex = 10;
            this.GeneratedPasswordsLabel.Text = "Generated passwords:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(287, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Loaded dictionary:";
            // 
            // loadedDictionaryPathTextBox
            // 
            this.loadedDictionaryPathTextBox.Location = new System.Drawing.Point(287, 155);
            this.loadedDictionaryPathTextBox.Name = "loadedDictionaryPathTextBox";
            this.loadedDictionaryPathTextBox.Size = new System.Drawing.Size(214, 20);
            this.loadedDictionaryPathTextBox.TabIndex = 13;
            this.loadedDictionaryPathTextBox.Text = "none";
            // 
            // allowedCharactersCheckedListBox
            // 
            this.allowedCharactersCheckedListBox.FormattingEnabled = true;
            this.allowedCharactersCheckedListBox.Items.AddRange(new object[] {
            "Capital letters [A-Z]",
            "Small letters [a-z]",
            "Numbers [0-9]",
            "Special characters (!,?,#...)"});
            this.allowedCharactersCheckedListBox.Location = new System.Drawing.Point(287, 181);
            this.allowedCharactersCheckedListBox.Name = "allowedCharactersCheckedListBox";
            this.allowedCharactersCheckedListBox.Size = new System.Drawing.Size(214, 64);
            this.allowedCharactersCheckedListBox.TabIndex = 16;
            // 
            // CharSetListBox
            // 
            this.CharSetListBox.FormattingEnabled = true;
            this.CharSetListBox.Items.AddRange(new object[] {
            "Polish Character Set",
            "English Charscter Set"});
            this.CharSetListBox.Location = new System.Drawing.Point(290, 28);
            this.CharSetListBox.Name = "CharSetListBox";
            this.CharSetListBox.Size = new System.Drawing.Size(211, 17);
            this.CharSetListBox.TabIndex = 17;
            this.CharSetListBox.SelectedIndexChanged += new System.EventHandler(this.CharSetListBox_SelectedIndexChanged);
            // 
            // openDictionaryFileDialog
            // 
            this.openDictionaryFileDialog.FileName = "openFileDialog1";
            // 
            // basicEnglishCharacterSet1
            // 
            this.basicEnglishCharacterSet1.Allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!\"#$%&\'()*+,-./:;<=" +
    ">?@[\\]^_`{|}~;";
            // 
            // polishCharacterSet1
            // 
            this.polishCharacterSet1.AllowDiacritics = false;
            this.polishCharacterSet1.Allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!\"#$%&\'()*+,-./:;<=" +
    ">?@[\\]^_`{|}~;ąćęłńóśźżĄĆĘŁŃÓŚŹŻ";
            this.polishCharacterSet1.AllowEnglishCharacters = false;
            this.polishCharacterSet1.Diacritics = "ąćęłńóśźżĄĆĘŁŃÓŚŹŻ";
            this.polishCharacterSet1.EnglishCharacters = "xXqQvV";
            // 
            // fileWordList1
            // 
            this.fileWordList1.Description = null;
            this.fileWordList1.WordList = null;
            // 
            // wordListFromService1
            // 
            this.wordListFromService1.Description = null;
            this.wordListFromService1.Id = "Moje";
            this.wordListFromService1.ServicePath = "http://172.20.101.7:8733/wordservice/";
            this.wordListFromService1.WordList = ((System.Collections.Generic.List<string>)(resources.GetObject("wordListFromService1.WordList")));
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 342);
            this.Controls.Add(this.CharSetListBox);
            this.Controls.Add(this.allowedCharactersCheckedListBox);
            this.Controls.Add(this.loadedDictionaryPathTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GeneratedPasswordsLabel);
            this.Controls.Add(this.generatedPasswordsTextBox);
            this.Controls.Add(this.descriptionTextBox);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.lengThextBox);
            this.Controls.Add(this.lengthLabel);
            this.Controls.Add(this.noOfPasswordsTextField);
            this.Controls.Add(this.noOfPasswordsLabel);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.mainMenuStrip);
            this.MainMenuStrip = this.mainMenuStrip;
            this.Name = "mainForm";
            this.Text = "Password Generator";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadDictionaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.Label noOfPasswordsLabel;
        private System.Windows.Forms.TextBox noOfPasswordsTextField;
        private System.Windows.Forms.TextBox lengThextBox;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox generatedPasswordsTextBox;
        private System.Windows.Forms.Label GeneratedPasswordsLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox loadedDictionaryPathTextBox;
        private System.Windows.Forms.CheckedListBox allowedCharactersCheckedListBox;
        private System.Windows.Forms.ListBox CharSetListBox;
        private System.Windows.Forms.OpenFileDialog openDictionaryFileDialog;
        private BasicEnglishCharacterSet basicEnglishCharacterSet1;
        private PolishCharacterSet polishCharacterSet1;
        private FileWordList fileWordList1;
        private WordListFromService wordListFromService1;
    }
}

