﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    interface IWordList
    {
        List<string> WordList {
            get;
            set;
        }
        string Description {
            get;
            set;
        }

        string GetRandomWord();
        string GetRandomWord(int n);
    }
}
