﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    abstract class CharacterSet : Component
    {
        [FlagsAttribute] public enum CharType {None = 0, UpperCase = 1, LowerCase = 2, Number = 4, Special = 8 };
        CharType characterFlags = CharType.UpperCase | CharType.LowerCase | CharType.Number | CharType.Special;

        string allowed;

        public string Allowed { get => allowed; set => allowed = value; }

        abstract public void addCharacters(string characters);

        abstract public void removeCharacters(string characters);

        public CharacterSet() {

        }

        abstract public void setFlags(CharType characterFlags);

        public CharacterSet(string additionalCharacters) 
 
        {
        }

        public CharacterSet(string additionalCharacters, string removeCharacters)

        {
        }

        public CharacterSet(string additionalCharacters, string removeCharacters, CharType allowedFlags)

        {
        }
    }
}
