﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyConfigurablePasswordGenerator
{
    public partial class mainForm : Form
    {
        private CharacterSet myCharacterSet;
        private FileWordList myFileWordList;

        public mainForm()
        {
            InitializeComponent();

        }

        internal CharacterSet MyCharacterSet { get => MyCharacterSet; set => MyCharacterSet = value; }
        internal FileWordList MyFileWordList { get => myFileWordList; set => myFileWordList = value; }

        private void CharSetListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (CharSetListBox.SelectedItem){
                case "Polish Character Set":
                    this.myCharacterSet = new PolishCharacterSet();
                    break;
                case "English Character Set":
                    this.myCharacterSet = new BasicEnglishCharacterSet();
                    break;
                default:
                    break;
            }
        }

        private void loadDictionaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = Application.StartupPath;
            if (fileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
                MyFileWordList = new FileWordList("",fileDialog.FileName);
            }
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            generatedPasswordsTextBox.Lines=wordListFromService1.WordList.ToArray();
        }
    }
}
