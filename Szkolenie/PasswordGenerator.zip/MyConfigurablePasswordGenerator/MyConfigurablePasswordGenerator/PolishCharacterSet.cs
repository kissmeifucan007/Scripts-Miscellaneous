﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    class PolishCharacterSet : BasicEnglishCharacterSet
    {
        public delegate void AllowedCharactersChangeHandler(PolishCharacterSet pcs, EventArgs e);

        public event AllowedCharactersChangeHandler DiacriticsHandler;
        public event AllowedCharactersChangeHandler EnglishCharactersHandler;

        string diacritics = "ąćęłńóśźżĄĆĘŁŃÓŚŹŻ";
        string englishCharacters = "xXqQvV";

        bool allowDiacritics;
        bool allowEnglishCharacters;

        public string Diacritics { get => diacritics; set => diacritics = value; }
        public string EnglishCharacters { get => englishCharacters; set => englishCharacters = value; }
        public bool AllowDiacritics { get => allowDiacritics; set => allowDiacritics = value; }
        public bool AllowEnglishCharacters { get => allowEnglishCharacters; set => allowEnglishCharacters = value; }

        public PolishCharacterSet() : base()
        {
            this.addDiacritics();
            DiacriticsHandler += new AllowedCharactersChangeHandler(DiacriticsSwitch);
            DiacriticsHandler += new AllowedCharactersChangeHandler(EnglishCharactersSwitch);
        }

        private void DiacriticsSwitch(PolishCharacterSet pcs, EventArgs e)
        {
            if (pcs.AllowDiacritics)
                pcs.addDiacritics();
            else
                pcs.removeDiacritics();
        }

        private void EnglishCharactersSwitch(PolishCharacterSet pcs, EventArgs e)
        {
            if (pcs.AllowDiacritics)
                pcs.addEnglishCharacters();
            else
                pcs.removeEnglishCharacters();
        }


        public void removeEnglishCharacters()
        {
            this.removeCharacters(EnglishCharacters);
        }

        public void addEnglishCharacters()
        {
            this.addCharacters(EnglishCharacters);
        }

        public void removeDiacritics() {
            this.addCharacters(Diacritics);
        }

        public void addDiacritics() {
            this.addCharacters(Diacritics);
        }
    }
}
