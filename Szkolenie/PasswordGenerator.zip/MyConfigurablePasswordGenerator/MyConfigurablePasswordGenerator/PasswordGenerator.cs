﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    class PasswordGenerator
    {
        CharacterSet myCharacterSet;
        FileWordList wordList;
        int length;
        int noOfWords;
        int minWordLength;

        public int MinWordLength { get => minWordLength; set => minWordLength = value; }
        public int NoOfWords { get => noOfWords; set => noOfWords = value; }
        public int Length { get => length; set => length = value; }
        internal CharacterSet MyCharacterSet { get => myCharacterSet; set => myCharacterSet = value; }

        public char randomCharFromString(String characters){
            Random rnd = new Random();
            // Return random character from 'characters'
            return(characters[rnd.Next(characters.Length)]);
                }

        public List<string> generatePasswords(int noOfPasswords) {
            List<string> passwordList = new List<string>();
            
            string newPassword ="";
            for (int i = 0; i < Length; i++)
            {
                newPassword += randomCharFromString(MyCharacterSet.Allowed);
            }
            passwordList.Add(newPassword);
            return passwordList;
        }

        public List<string> generatePasswords() {
            return this.generatePasswords(1);
        }

    }
}
