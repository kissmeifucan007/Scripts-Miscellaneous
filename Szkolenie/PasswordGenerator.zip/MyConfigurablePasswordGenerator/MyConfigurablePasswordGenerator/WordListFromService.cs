﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    class WordListFromService : SimpleWordList
    {
        private string servicePath= @"http://172.20.101.7:8733/wordservice/";
        string id;

        public WordListFromService() : base()
        {
        }

        public WordListFromService(string servicePath) :base(){
            this.ServicePath = servicePath;
        }

        public override List<string> WordList {
            get {
                try
                {
                    if (!this.DesignMode)
                    {
                        Service.WordServiceClient client = new Service.WordServiceClient();
                        client.Endpoint.Address = new System.ServiceModel.EndpointAddress(ServicePath);
                        wordList = client.GetWordList(Id).ToList();
                    }
                }
                catch { }
                return wordList;
            } set => base.WordList = value; }
        public string Id { get => id; set => id = value; }
        public string ServicePath { get => servicePath; set => servicePath = value; }
    }
}
