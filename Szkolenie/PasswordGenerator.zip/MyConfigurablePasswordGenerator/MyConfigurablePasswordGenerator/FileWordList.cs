﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    class FileWordList: SimpleWordList
    {
        string filePath;

        public void AddWord(string word) {
            this.wordList.Add(word);
        }
        public FileWordList()
        {

        }
        public FileWordList(string description, string filePath) 
            :base(description)
        {
            this.filePath = filePath;
            foreach (string line in File.ReadLines(filePath))
            {
                AddWord(line);
            }
        }
    }
}
