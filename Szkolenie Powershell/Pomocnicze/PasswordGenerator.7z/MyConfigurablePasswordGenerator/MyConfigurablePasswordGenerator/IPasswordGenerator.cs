﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    interface IPasswordGenerator
    {
        string Description { get; set; }
        int PasswordMinLength { get; set; }
        string allowedCharacters { get; set; }
        File dictionary { get; set; }

        string generatePassword();
        string generatePassword(int noOfPasswords);

    }
}
