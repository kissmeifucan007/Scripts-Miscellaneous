﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MyConfigurablePasswordGenerator
{
    class BasicEnglishCharacterSet : CharacterSet
    {
        CharType characterFlags = CharType.UpperCase | CharType.LowerCase | CharType.Number | CharType.Special;

        

        string allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~;";

        public string Allowed { get => allowed; set => allowed = value; }

        override public void addCharacters(string characters)
        {
            for (int i = 0; i < characters.Length; i++)
            {
                if (!this.Allowed.Contains(characters[i]))
                    this.Allowed += characters[i];
            }
        }

        override public void removeCharacters(string characters)
        {
            Regex.Replace(Allowed, characters, string.Empty);
        }

        public BasicEnglishCharacterSet()
        {

        }

        override public void setFlags(CharType characterFlags)
        {
            this.characterFlags = characterFlags;
        }

        public BasicEnglishCharacterSet(string additionalCharacters)
            : this()
        {
            this.addCharacters(additionalCharacters);
        }

        public BasicEnglishCharacterSet(string additionalCharacters, string removeCharacters)
            : this(additionalCharacters)
        {
            this.removeCharacters(removeCharacters);
        }

        public BasicEnglishCharacterSet(string additionalCharacters, string removeCharacters, CharType allowedFlags)
            : this(additionalCharacters, removeCharacters)
        {
            this.setFlags(allowedFlags);
        }
    }
}
