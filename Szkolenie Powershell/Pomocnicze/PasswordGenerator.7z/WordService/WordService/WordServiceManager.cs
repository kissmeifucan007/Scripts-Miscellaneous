﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WordService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class WordServiceManager : IWordService
    {

        public List<string> GetWordList(string id)
        {
            return System.IO.File.ReadLines(id+".txt").ToList();
        }

        public void addWord(string word, string id)
        {
            
           var w= System.IO.File.AppendText(id + ".txt");
            w.WriteLine(word);
            w.Close();
        }
    }
}
